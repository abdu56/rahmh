package ru.SnowVolf.girl.annotation

/**
 * Created by Snow Volf on 08.12.2017, 16:10
 */

annotation class Experimental
