package ru.SnowVolf.pcompiler.patch


/**
 * Created by Snow Volf on 27.10.2017, 17:37
 */

internal class PatchException : IndexOutOfBoundsException()
