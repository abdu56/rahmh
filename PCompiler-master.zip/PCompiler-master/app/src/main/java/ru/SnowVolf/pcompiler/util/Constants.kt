package ru.SnowVolf.pcompiler.util

/**
 * Created by Snow Volf on 19.08.2017, 13:51
 */

object Constants {
    val KEY_EXTRA_FILES = "extra_files_path"
    val KEY_EXTRA_DEXES = "extra_dexes_path"

    val TAG = "PCompiler"
}
